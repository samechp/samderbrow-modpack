#ifndef COLORWHEELTINT_GLSL
#define COLORWHEELTINT_GLSL

// ---- Solar Shader Color Wheel options (discovered via #define + [value list]) ----
#define CW_HUE 0.0 // Global light hue rotation [0.0 10.0 20.0 30.0 40.0 50.0 60.0 70.0 80.0 90.0 100.0 110.0 120.0 130.0 140.0 150.0 160.0 170.0 180.0 190.0 200.0 210.0 220.0 230.0 240.0 250.0 260.0 270.0 280.0 290.0 300.0 310.0 320.0 330.0 340.0 350.0 360.0]
#define CW_SATURATION 1.0 // Light saturation [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define CW_STRENGTH 0.0 // Color wheel blend strength (0=off) [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

vec3 cwHue2rgb(float h) {
    h = mod(h, 360.0);
    float s = h / 60.0;
    float f = fract(s);
    float q = 1.0 - f;
    if (s < 1.0) return vec3(1.0, f,   0.0);
    if (s < 2.0) return vec3(q,   1.0, 0.0);
    if (s < 3.0) return vec3(0.0, 1.0, f  );
    if (s < 4.0) return vec3(0.0, q,   1.0);
    if (s < 5.0) return vec3(f,   0.0, 1.0);
                 return vec3(1.0, 0.0, q  );
}

vec3 applyColorWheelTint(vec3 lighting) {
    #if CW_STRENGTH < 0.01
    return lighting;
    #else
    float lum = dot(lighting, vec3(0.2126, 0.7152, 0.0722));
    vec3 tinted = mix(vec3(lum), cwHue2rgb(CW_HUE) * lum, CW_SATURATION);
    return mix(lighting, tinted, CW_STRENGTH);
    #endif
}
#endif
